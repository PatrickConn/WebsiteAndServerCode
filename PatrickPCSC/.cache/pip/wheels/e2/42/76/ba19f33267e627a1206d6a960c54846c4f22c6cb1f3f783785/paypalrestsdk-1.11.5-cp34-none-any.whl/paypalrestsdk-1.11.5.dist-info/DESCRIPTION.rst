
The PayPal REST SDK provides Python APIs to create, process and manage payments.

1. https://github.com/paypal/PayPal-Python-SDK/ - README and Samples
2. https://developer.paypal.com/webapps/developer/docs/api/ - API Reference


