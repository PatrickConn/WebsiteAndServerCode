The UseDatabase context manager for working with MySQL/MariaDB.
