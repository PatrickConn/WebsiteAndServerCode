Compatibility tests for Let's Encrypt client
