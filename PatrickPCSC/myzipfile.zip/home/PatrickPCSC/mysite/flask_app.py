# Patrick Connauhotn
# C00167985
from flask import Flask,flash,redirect,url_for, render_template, request, jsonify, session,request
import DBcm
from threading import Thread
import hashlib , uuid
from functools import wraps
import base64
import smtplib
import base64
from passlib.hash import sha256_crypt
import paypalrestsdk
import logging
import random
import string
import sys
import mysql.connector
from mysql.connector.constants import ClientFlag
from requests.auth import HTTPBasicAuth
import json
import ctypes
import flask_login
import requests
from werkzeug.datastructures import ImmutableOrderedMultiDict
import sqlparse
import requests
from requests.auth import HTTPBasicAuth
import json
#from MySQLdb import escape_string as thwart


DBconfig = { 'host': '127.0.0.1',
                 'user': 'PatrickPCSC',
                 'password': 'p30401',
                 'database': 'PatrickPCSC$PCSC' }


app = Flask(__name__)


def check_login(func):
	@wraps(func)
	def wrapped_function(*args, **kwargs):
		if 'logged_in' in session:
			return func(*args, **kwargs)
		return 'You are NOT logged in. Please login to continue.'
	return wrapped_function

# def sendEmail(email):
	# Sender = "c00167985@gmail.com"
	# Sender_password = "Patpassword"
	# To = email
	# Subject = "Vrify you're accont"
	# Text = """This link will verify you're accont \n http://127.0.0.1:5000/show/page/3"""

	# message = """\From: %s\nTo: %s\nSubject: %s\nText: %s
	# """ % (Sender, ",".join(To), Subject, Text)
	# Body = '\r\n'.join(['To: %s' % To,
                # 'From: %s' % Sender,
                # 'Subject: %s' % Subject,
                # '', Text])

	# smtpserver = smtplib.SMTP("smtp.gmail.com",587)
	# smtpserver.ehlo()
	# smtpserver.starttls()
	# smtpserver.ehlo()
	# smtpserver.login(Sender , Sender_password)
	# smtpserver.sendmail(Sender, To, Body)
	# smtpserver.close()


@app.route('/show/page/<num>')
def display_page(num:int) -> 'html':
    tplt = 'page' + str(num) + '.html'
    return render_template(tplt)


def Add_User(username:str, password:str, Email:str,First_Name:str,Last_Name:str):
    with DBcm.UseDatabase(DBconfig) as cursor:
        _SQL = "insert into Users_Table (User_First_Name,User_Last_Name,User_Name, User_Password, User_Email ,User_Balance) values (%s, %s, %s,%s,%s,%s)"
        cursor.execute(_SQL, (First_Name,Last_Name,username,password , Email, 0,))



@app.route('/data', methods=['POST'])
def Add_New_User() -> 'html':
	error = None
	User1 = request.form['User']
	Password1 = request.form['Password']
	Email = request.form['Email']
	Fname = request.form['Fname']
	Lname = request.form['Lname']
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "SELECT User_Name FROM Users_Table WHERE User_Name=%s"
		cursor.execute(_SQL, (User1,))
		data = cursor.fetchall ()
	if not data:
		Password1 = sha256_crypt.encrypt(Password1)
		#sendEmail(Email)
		Add_User(User1, Password1, Email,Fname,Lname)
		session['logged_in'] = True
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "SELECT User_Id FROM Users_Table WHERE User_Name=%s"
			cursor.execute(_SQL, (User1,))
			data = cursor.fetchall()
		id = ','.join(str(v) for v in data[0])
		session['User_ID'] = id
		return render_template('results.html',
						the_title = 'Thank you for singing up you can go and play',
						User=User1,
						Email=Email,)
	else:
		error = 'Invalid credentials'
		return render_template('home.html' , error=error,)


@app.route('/login', methods=['POST'])
def Login_User() -> 'html':
    User = request.form['User']
    Password1 = request.form['Password']
    with DBcm.UseDatabase(DBconfig) as cursor:
        _SQL = "SELECT User_Confirmed FROM Users_Table WHERE User_Name=%s"
        cursor.execute(_SQL, (User,))
        data = cursor.fetchall()
    error = ""
    if not data:
        error = 'Your username or password was incorrect'
        return render_template('page1.html' , error=error,)
    test = ','.join(str(v) for v in data[0])
    test = "1"
    if test != "1":
        error = 'Your accont in not validatait please validatia your accont'
        return render_template('page1.html' , error=error,)
    else:
        with DBcm.UseDatabase(DBconfig) as cursor:
            _SQL = "SELECT User_Password FROM Users_Table WHERE User_Name=%s"
            cursor.execute(_SQL, (User,))
            data = cursor.fetchall()
    if not data:
        error = 'Sorry you login faled please go back and try again'
        return render_template('page1.html' , error=error,)
    else:
        test = ','.join(str(v) for v in data[0])
        if sha256_crypt.verify(Password1 , test):
            session['logged_in'] = True
            with DBcm.UseDatabase(DBconfig) as cursor:
                _SQL = "SELECT User_Id FROM Users_Table WHERE User_Name=%s"
                cursor.execute(_SQL, (User,))
                data = cursor.fetchall()
            id = ','.join(str(v) for v in data[0])
            with DBcm.UseDatabase(DBconfig) as cursor:
                _SQL = "SELECT User_Balance FROM Users_Table WHERE User_Name=%s"
                cursor.execute(_SQL, (User,))
                data = cursor.fetchall()
            Balance = ','.join(str(v) for v in data[0])
            session['User_ID'] = id
            return render_template('home.html',login="1",User_Balance = Balance)
        else:
            error = 'Sorry you login faled please go back and try again'
            return render_template('page1.html' , error=error, )



@app.route('/login/andriod', methods=['GET','POST'])
def Log_Andriod():
    test = ""
    error = ""
    username = request.args.get('User')
    password = request.args.get('Pass')
    with DBcm.UseDatabase(DBconfig) as cursor:
        _SQL = "SELECT User_Confirmed FROM Users_Table WHERE User_Name=%s"
        cursor.execute(_SQL, (username,))
        data = cursor.fetchall()
    if not data:
        error = 'Your username or password was incorrect'
        return str({"success":1,"login":[{"Login":"2"},{"Error":error}]})
    test = ','.join(str(v) for v in data[0])
    test = "1"
    if test != "1":
        error = 'Your accont in not validatait please validatia your accont'
        return str({"success":1,"login":[{"Login":"2"},{"Error":error}]})
    else:
        with DBcm.UseDatabase(DBconfig) as cursor:
            _SQL = "SELECT User_Password FROM Users_Table WHERE User_Name=%s"
            cursor.execute(_SQL, (username,))
            data = cursor.fetchall()
    if not data:
        error = 'Sorry you login faled please go back and try again'
        return str({"success":1,"login":[{"Login":"2"},{"Error":error}]})
    else:
        test = ','.join(str(v) for v in data[0])
        if sha256_crypt.verify(password , test):
            with DBcm.UseDatabase(DBconfig) as cursor:
                _SQL = "SELECT User_Id FROM Users_Table WHERE User_Name=%s"
                cursor.execute(_SQL, (username,))
                data = cursor.fetchall()
            id = ','.join(str(v) for v in data[0])
            with DBcm.UseDatabase(DBconfig) as cursor:
                _SQL = "SELECT User_Balance FROM Users_Table WHERE User_Id=%s"
                cursor.execute(_SQL, (id,))
                data = cursor.fetchall()
                Balance = ','.join(str(v) for v in data[0])
            return str({"success":1,"login":[{"Login":"1"},{"User_Id":id},{"Balance":Balance}]})
        else:
            error = 'Sorry you login faled please go back and try again'
            return str({"success":1,"login":[{"Login":"2"},{"Error":error}]})




@app.route('/android/Sign_up', methods=['GET','POST'])
def Sign_up():
    username = request.args.get("User")
    password = request.args.get("Pass")
    Email = request.args.get("Email")
    First_Name = request.args.get("firstName")
    Last_Name = request.args.get("lastName")
    with DBcm.UseDatabase(DBconfig) as cursor:
        _SQL = "SELECT User_Name FROM Users_Table WHERE User_Name=%s"
        cursor.execute(_SQL, (username,))
        data = cursor.fetchall ()
    if not data:
        Password1 = sha256_crypt.encrypt(password)
        #sendEmail(Email)
        Add_User(username, Password1, Email,First_Name,Last_Name)
        with DBcm.UseDatabase(DBconfig) as cursor:
            _SQL = "SELECT User_Id FROM Users_Table WHERE User_Name=%s"
            cursor.execute(_SQL, (username,))
            data = cursor.fetchall()
        id = ','.join(str(v) for v in data[0])
        id = sha256_crypt.encrypt(id)
        return str({"success":1,"Add":[{"Login":"1"},{"User_id":id}]})
    else:
        error = 'Invalid credentials'
        return str({"success":1,"Add":[{"Login":"2"},{"Error":error}]})





@app.route('/Validation', methods=['POST'])
def Validation_User() -> 'html':
	User = request.form['User']
	Password = request.form['Password']
	confrom = True
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "UPDATE Users_Table SET confrom=%s WHERE User_Name=%s"
		cursor.execute(_SQL, (confrom, User))
		error = 'Your account has been validation'
		return render_template('page2.html' , error=error,)



@app.route('/logout')
def logout():
	session.clear()
	return render_template('home.html',login="0",)

@app.route('/home')
def home():
    if 'logged_in' in session:
        with DBcm.UseDatabase(DBconfig) as cursor:
            _SQL = "SELECT User_Balance FROM Users_Table WHERE User_Id=%s"
            cursor.execute(_SQL, (session['User_ID'] ,))
            data = cursor.fetchall()
        Balance = ','.join(str(v) for v in data[0])
        return render_template('home.html',login="1",User_Balance = Balance)
    else:
	    return render_template('home.html',login="0")



@app.route('/PayPal')
# @check_login
def PayPal():
    return render_template('PayPal.html',the_title='Add You Crad Details below',)


@app.route('/PlayCards')
def PlayCards():
	return render_template('PlayCards.html')



@app.route('/Addmoney', methods=[ 'POST'])
def DepositMoney() -> 'html':
	CHFName = request.form['FName']
	CHLName = request.form['LName']
	Amount = request.form['Amount']
	CardType = request.form['CType']
	CaedNumber = request.form['Cnumber']
	EM = request.form['EM']
	EY = request.form['EY']
	CVV2 = request.form['CVV2']
	payment_result = MakeAPayment(CardType,CaedNumber,EM,EY,CVV2,CHFName,CHLName,Amount)
	if payment_result == True:
		return 'successful'
	else:
		return 'unsuccessful'

@app.route('/status')
def show_status():
    if 'logged_in' in session:
        return 'You are currently logged in.'
    return 'You are NOT logged in. Please login to continue.'

app.secret_key = 'password'


@app.route('/PayPalPrchase',methods=['POST','GET'])
def purchase():
    payment_gross = 10.00
    with DBcm.UseDatabase(DBconfig) as cursor:
        _SQL = "UPDATE Users_Table SET User_Balance=%s WHERE User_Id=%s"
        cursor.execute(_SQL, (float(Amount),session['User_ID'],))
    return render_template("home.html")


@app.route('/ipn/',methods=['POST'])
def ipn():
	try:
		arg = ''
		request.parameter_storage_class = ImmutableOrderedMultiDict
		values = request.form
		for x, y in values.iteritems():
			arg += "&{x}={y}".format(x=x,y=y)

		validate_url = 'https://www.sandbox.paypal.com' \
					   '/cgi-bin/webscr?cmd=_notify-validate{arg}' \
					   .format(arg=arg)
		r = requests.get(validate_url)
		if r.text == 'VERIFIED':
			try:
				payer_email =  thwart(request.form.get('payer_email'))
				unix = int(time.time())
				payment_date = thwart(request.form.get('payment_date'))
				username = thwart(request.form.get('custom'))
				last_name = thwart(request.form.get('last_name'))
				payment_gross = thwart(request.form.get('payment_gross'))
				payment_fee = thwart(request.form.get('payment_fee'))
				payment_net = float(payment_gross) - float(payment_fee)
				payment_status = thwart(request.form.get('payment_status'))
				txn_id = thwart(request.form.get('txn_id'))
			except Exception as e:
				with open('/tmp/ipnout.txt','a') as f:
					data = 'ERROR WITH IPN DATA\n'+str(values)+'\n'
					f.write(data)

			with open('/tmp/ipnout.txt','a') as f:
				data = 'SUCCESS\n'+str(values)+'\n'
				f.write(data)

			c,conn = connection()
			c.execute("INSERT INTO ipn (unix, payment_date, username, last_name, payment_gross, payment_fee, payment_net, payment_status, txn_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
						(unix, payment_date, username, last_name, payment_gross, payment_fee, payment_net, payment_status, txn_id))
			conn.commit()
			c.close()
			conn.close()
			gc.collect()

		else:
			with open('/tmp/ipnout.txt','a') as f:
				data = 'FAILURE\n'+str(values)+'\n'
				f.write(data)

		return r.text
	except Exception as e:
		return str(e)

#http://stackoverflow.com/questions/15899873/generate-random-numbers-with-known-discrete-probabilities-in-python
def weighted_random(weights):
    number = random.random() * sum(weights.values())
    for k,v in weights.items():
        if number < v:
           # print ("break" , v)
            break
        number -= v
        #print (number)
    return k

def xrange(x):
    return iter(range(x))


# the following values can be any non-negative numbers, no need of sum=100
weights = {'0': 150.0,
           '10': 13.0,
           '25': 6.0,
           '50': 3.0,
           '100': 2.0,
           '200': 1.0}



	#http://stackoverflow.com/questions/2257441/random-string-generation-with-upper-case-letters-and-digits-in-python
def id_generator(size=10, chars=string.ascii_uppercase + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))

	#winOrLose+Value+session['User_ID']
@app.route('/GetCards', methods=['POST','GET'])
def GetCards() -> 'html':
	Value = weighted_random(weights)
	Balance = ""
	error = "did not wock"
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "SELECT User_Balance FROM Users_table WHERE User_Id=%s"
		cursor.execute(_SQL,(session['User_ID'],))
		data = cursor.fetchall()
	OLDBalance = ','.join(str(v) for v in data[0])
	if float(OLDBalance) < 2.000:
		error="Sorry you need to add money to your accont to buy a new card"
		return render_template('PlayCards.html',error=error,)
	NewBalance = float(OLDBalance) - 2
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "UPDATE Users_Table SET User_Balanc=%s WHERE User_Id=%s"
		cursor.execute(_SQL, (NewBalance,session['User_ID'],))
	if Value == '0':
		winOrLose = "Lose"
	else:
		winOrLose = "WIN"
	if Value == '0':
		pass
	else:
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "SELECT User_Balance FROM Users_table WHERE User_Id=%s"
			cursor.execute(_SQL,(session['User_ID'],))
			data = cursor.fetchall()
		OLDBalance = ','.join(str(v) for v in data[0])
		NewBalance = float(OLDBalance) + float(Value)
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "UPDATE Users_Table SET User_Balance=%s WHERE User_Id=%s"
			cursor.execute(_SQL, (NewBalance,session['User_ID'],))
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "insert into BackUp_Table (User_id, New_Balance, Old_Balance ,Card_Name,Card_value)values (%s, %s, %s,%s)"
			cursor.execute(_SQL, (session['User_ID'], NewBalance, OLDBalance, winOrLose,Value))
	return render_template('PlayCards.html',error=winOrLose+Value,)


@app.route('/PayPalSuccess')
def success():
	return PayOut('pctestpay@test.com',10.00)




def PayOut(user_email,total_amount):
	logging.basicConfig(level=logging.INFO)
	PAYPAL_MODE = "sandbox"
	PAYPAL_CLIENT_ID = "AXwzmtJ78RmGMzUAaQeYhD8gekNg4hDjxmccdfKYYu-OrS8I3lAI-i0JjA1G-lvaY9mjG2xXqD_d7pv1"
	PAYPAL_CLIENT_SECRET = "EKThiQ3ZKh8sl5rfLmMYTSTzBEpEjfjOq_L_yDPpf8GtJQBk97FE5Yi0WHCYUOUumFm60x5Hz8tFEWZn"
	url = "https://api.sandbox.paypal.com/v1/oauth2/token"
	headers = {'Accept': 'application/json','Accept-Language': 'en_US'}
	payload = {'grant_type': 'client_credentials'}
	token_response = requests.post(url, auth=HTTPBasicAuth(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET), headers=headers, data=payload)
	body = json.loads(token_response.text)
	authoize_token = body['token_type'] + " " + body['access_token']


	sender_batch_id = ''.join(random.choice(string.ascii_uppercase) for i in range(12))
	payouturl = "https://api.sandbox.paypal.com/v1/payments/payouts/"
	payoutheaders = {'Content-Type':'application/json','Authorization': ""+authoize_token}
	payoutpayload =  {
    "sender_batch_header": {
        "sender_batch_id": sender_batch_id,
        "email_subject": "You have a Payout!",
        "recipient_type": "EMAIL"
    },
    "items": [
        {
            "amount": {
                "value": total_amount,
                "currency": "USD"
            },
            "receiver": user_email
        }
    ]
  }

	paramvalue = {'sync_mode': 'true'}

	payout_response = requests.post(payouturl, headers=payoutheaders, data=json.dumps(payoutpayload), params=paramvalue)
	#return str(payout_response)
	payout_body = json.loads(payout_response.text)
	status = payout_body['batch_header']
	return str(status['batch_status'])


@app.route('/android/BuyACard', methods=['POST','GET'])
def GetCards() -> 'html':
	Value = weighted_random(weights)
	Balance = ""
	error = "did not wock"
	User_Id = request.args.get("User_id")
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "SELECT User_Balance FROM Users_table WHERE User_Id=%s"
		cursor.execute(_SQL,(User_Id,))
		data = cursor.fetchall()
	OLDBalance = ','.join(str(v) for v in data[0])
	if float(OLDBalance) < 2.000:
		error="Sorry you need to add money to your accont to buy a new card"
        return str({"success":1,"buy":[{"buyAcard":"0"},{"Error":error}]})
	NewBalance = float(OLDBalance) - 2
	with DBcm.UseDatabase(DBconfig) as cursor:
		_SQL = "UPDATE Users_Table SET User_Balanc=%s WHERE User_Id=%s"
		cursor.execute(_SQL, (NewBalance,User_Id,))
	if Value == '0':
		winOrLose = "Lose"
	else:
		winOrLose = "WIN"
	if Value == '0':
		pass
	else:
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "SELECT User_Balance FROM Users_table WHERE User_Id=%s"
			cursor.execute(_SQL,(User_Id,))
			data = cursor.fetchall()
		OLDBalance = ','.join(str(v) for v in data[0])
		NewBalance = float(OLDBalance) + float(Value)
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "UPDATE Users_Table SET User_Balance=%s WHERE User_Id=%s"
			cursor.execute(_SQL, (NewBalance,User_Id,))
		with DBcm.UseDatabase(DBconfig) as cursor:
			_SQL = "insert into BackUp_Table (User_id, New_Balance, Old_Balance ,Card_Name,Card_value)values (%s, %s, %s,%s)"
			cursor.execute(_SQL, (User_Id, NewBalance, OLDBalance, winOrLose,Value))
    return str({"success":1,"buy":[{"buyAcard":"1"},{"NewBalance":NewBalance},{"OLDBalance":OLDBalance},{"winOrLose":winOrLose},{"Value":Value}]})



if __name__ == "__main__":
    app.run(debug=True)
